# Code of Conduct

Use this project for responsible rights screening, evidence organization, creator protection, and lawyer-ready analysis. Do not use it for bad-faith takedowns, extortion, deceptive claims, harassment, or suppression of legitimate fair use, research, commentary, interoperability, or open-source activity.
