# Security Policy

The offline core should not contain network access, subprocess execution, dynamic code execution, hidden telemetry, or host mutation helpers.

Report suspected vulnerabilities or misuse patterns to the project maintainers.
