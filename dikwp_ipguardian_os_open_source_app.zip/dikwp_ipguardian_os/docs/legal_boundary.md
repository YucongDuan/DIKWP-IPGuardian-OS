# Legal Boundary

DIKWP IPGuardian OS does not provide legal advice and does not produce final infringement conclusions.

## Required human review

Human legal review is required before:

- public accusation;
- lawyer letter;
- platform takedown;
- administrative complaint;
- civil lawsuit;
- criminal complaint;
- public naming of suspected infringer;
- publication of infringement score.

## Forbidden use

Do not use this system to:

- harass competitors;
- suppress criticism, research, interoperability or fair use;
- issue mass bad-faith takedowns;
- access private systems without authorization;
- steal credentials or non-public documents;
- misrepresent registry or authorization status;
- claim official DIKWP certification without official grant.

## Recommended wording before evidence closure

Use:

- suspected use;
- potential overlap;
- please clarify source and authorization;
- further evidence required;
- rights-chain and claim-chart review pending.

Avoid:

- already infringed;
- definitely illegal;
- stolen;
- criminal;
- 100% infringement.
