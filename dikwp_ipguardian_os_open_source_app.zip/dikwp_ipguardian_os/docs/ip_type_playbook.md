# IP Type Playbook

## Patent

A semantic theme overlap is not enough. The target technical solution must map to all elements of at least one enforceable patent claim. Backend implementation evidence is often decisive.

## Copyright

Copyright protects expression, not abstract ideas, methods, concepts or facts. The system therefore separates conceptual similarity from expression-level similarity.

## Trademark

Trademark analysis focuses on use as a mark, similarity, goods/services overlap, channels, consumer confusion and unfair competition risk.

## Trade secret

Trade secret risk requires non-public valuable information, reasonable secrecy measures and improper acquisition, disclosure or use.

## Open-source attribution

Open-source license violation and attribution removal can be triaged through NOTICE, LICENSE, CITATION and provenance files.

## DIKWP semantic-space IP

DIKWP-specific protection often involves layered evidence: terminology, method structure, patent claim elements, software implementation, training material, registry identity and commercial packaging.
