# Integration Guide

DIKWP IPGuardian OS can integrate with:

- TrustPassport OS: verify official DIKWP project identity.
- OriginMoat OS: decide what should be open-sourced and what should be controlled.
- EcosystemRouter OS: route copycat risk into partner/certification pathway.
- ProofLedger OS: check claim-to-evidence alignment.
- AgentTrace OS: record investigation workflow traces.
- AnswerGraph Studio: monitor brand and DIKWP term use in AI answer engines.
- AICAP Gateway OS: protect protocol and industry adapter assets.
