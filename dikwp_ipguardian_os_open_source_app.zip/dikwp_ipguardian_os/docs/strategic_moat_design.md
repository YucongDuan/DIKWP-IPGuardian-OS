# Strategic Moat Design for Yucong Duan / DIKWP

DIKWP IPGuardian OS should not only detect suspected infringement. It should strengthen the DIKWP ecosystem moat.

## Moat layers

1. **Origin evidence**: commit history, publication history, timestamps, drafts, screenshots, patent filings.
2. **TrustPassport**: every official DIKWP project receives a verifiable trust passport.
3. **Registry**: public registry entries make official projects visible.
4. **Attribution default**: NOTICE and CITATION files make referencing easy.
5. **Certification**: official DIKWP certification and badges cannot be honestly copied by forks.
6. **Enforcement readiness**: the ecosystem has a consistent evidence-ledger and claim-chart workflow.
7. **Partner conversion**: copycats are first invited to clarify, attribute, license or register before escalation.

## Open-core strategy

Open-source the screening core and schema. Keep official registry keys, certification decisions, verified partner lists, evidence vault and legal service workflow under controlled governance.
