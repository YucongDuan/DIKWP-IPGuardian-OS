# Open Source Launch Plan

1. Publish a public demo with non-sensitive synthetic cases.
2. Include NOTICE and CITATION.cff from day one.
3. Register the project in DIKWP TrustPassport Registry.
4. Publish a Chinese product brief and English technical README.
5. Avoid publishing real unresolved dispute details without legal approval.
6. Offer a paid official evidence review and DIKWP IP protection workshop.
7. Create partner routes for law firms, IP agencies, open-source maintainers and enterprise risk teams.
