# DIKWP Model Mapping for IP Protection

## D / Data
- protected text, claims, figures, source code, marks, screenshots, URLs, logs, product materials.

## I / Information
- relationships among rights assets, target features, channels, actors, authorization state and timing.

## K / Knowledge
- IP-type-specific legal theory: patent all-elements rule, copyright expression similarity, trademark confusion, trade-secret secrecy and misuse.

## W / Wisdom
- avoid overclaiming, bad-faith takedowns, public accusations without evidence, harassment and suppression of lawful uses.

## P / Purpose
- protect legitimate creators and innovators while preserving open research, legitimate reference, interoperability, fair dealing/fair use and public-domain boundaries.

## R / Reliability
- source custody, official registry verification, legal review, evidence completeness, claim-chart confidence and residuals.
