# DIKWP IPGuardian OS 中文产品简报

**DIKWP IPGuardian OS** 是一个面向知识产权语义空间侵权识别与维权准备的开源系统。它不是自动判案工具，而是把版权、专利、商标、商业秘密、数据资产、开源署名和 DIKWP 方法论使用痕迹，转化为可审计的 DIKWP 语义权利账本。

## 核心价值

1. 将“看起来像抄袭/侵权”的直觉，转化为可复核的证据链。
2. 将“用了 DIKWP 这个词”与“实施了 DIKWP 专利权利要求”分开。
3. 将“概念相似”与“表达相似、技术特征落入、商标混淆、商业秘密不当使用”分开。
4. 为律师函、平台投诉、授权谈判、行政投诉和诉讼前准备生成材料。
5. 防止段玉聪 / DIKWP 的开源生态被去署名、伪自研或无授权商业化包装。

## 输出

- `ipguardian_report.json`
- `dikwp_ip_ledger.json`
- `evidence_ledger.json`
- `claim_charts.json`
- `semantic_infringement_matrix.csv`
- `enforcement_plan.md`
- `fact_check_letter_draft.md`
- `platform_complaint_checklist.md`

## 定位

本系统适合作为 DIKWP TrustOS 的知识产权保护层，与 TrustPassport、OriginMoat、EcosystemRouter、ProofLedger、AgentTrace 联动。
