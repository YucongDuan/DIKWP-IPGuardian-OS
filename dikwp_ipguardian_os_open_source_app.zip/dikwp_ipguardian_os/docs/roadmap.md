# Roadmap

## v0.2
- Better Chinese text segmentation.
- Rights-chain registry connector.
- Patent claim-chart XLSX export.
- Trademark confusion questionnaire.
- Copyright protectable-expression classifier.

## v0.3
- TrustPassport integration.
- Platform complaint templates.
- Evidence vault connector.
- Lawyer review workflow.

## v1.0
- Official DIKWP IP Registry dashboard.
- Certified law-firm / IP-agency partner workflow.
- Enterprise license monitoring service.
- Cross-jurisdiction policy packs.
