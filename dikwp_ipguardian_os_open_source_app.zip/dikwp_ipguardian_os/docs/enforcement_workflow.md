# Enforcement Workflow

## Stage 1: Rights chain

- Confirm owner, assignment, license and standing.
- Verify patent/trademark status and copyright authorship.
- Confirm whether asset is protected, expired, abandoned, public domain, open licensed or subject to exceptions.

## Stage 2: Evidence preservation

- Capture public pages, screenshots, videos, ads, product manuals and AI answers.
- Preserve timestamps and hash values.
- Consider notarization, trusted timestamps or evidence preservation through counsel.

## Stage 3: Semantic comparison

- Copyright: protectable expression, substantial similarity, access and exclusion of ideas/methods.
- Patent: every claim element mapped to target implementation evidence.
- Trademark: mark similarity, goods/services overlap, use-as-mark, confusion risk.
- Trade secret: secrecy measures, access path, non-public value and improper acquisition/use.

## Stage 4: Authorization and defenses

Check license, assignment, collaboration, independent creation, prior art, fair use/fair dealing, public domain, exhaustion, descriptive use, nominative use, interoperability and statutory exceptions.

## Stage 5: Graduated response

- Private fact-check request.
- Correction/attribution request.
- License negotiation.
- Platform complaint.
- Administrative complaint.
- Evidence preservation application.
- Civil litigation or arbitration.

## Stage 6: Recovery and de-escalation

If evidence is weak or defenses are valid, downgrade the claim, retract overbroad statements and update the evidence ledger.
