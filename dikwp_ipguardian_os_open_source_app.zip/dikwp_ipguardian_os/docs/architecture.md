# Architecture

DIKWP IPGuardian OS follows a six-stage architecture:

1. **Rights Intake**: IPAsset records for patent, copyright, trademark, trade secret, data asset and open-source attribution.
2. **Suspected Use Intake**: target public text, product features, marks, evidence and authorization claims.
3. **DIKWP Registration**: D/I/K/W/P/R registration for both source rights and target use.
4. **Semantic Space Comparison**: heuristic overlap, claim-element mapping, expression similarity, mark confusion and trade-secret risk.
5. **Evidence Ledger and Residual Queue**: separate evidence from suspicion and register missing materials.
6. **Enforcement Preparation**: rights-chain review, evidence preservation, clarification letter, takedown checklist and lawyer-ready issue list.

The system is intentionally offline-first. It does not scrape, hack, send takedown notices, contact platforms or operate as legal advice.
