from dikwp_ipguardian.analyzer import load_case, analyze
from dikwp_ipguardian.static_audit import run_static_audit


def test_demo_case_runs():
    case = load_case('examples/sample_ip_case.json')
    res = analyze(case)
    assert res.case_id == 'dikwp-ip-demo-001'
    assert res.signals
    assert res.decision in {'lawyer_review_and_evidence_preservation_urgent','evidence_preservation_and_rights_chain_review','monitor_and_collect_more_evidence','low_current_evidence_no_accusation'}


def test_static_audit_passes():
    report = run_static_audit('src')
    assert report['pass'] is True


def test_claim_charts_present():
    res = analyze(load_case('examples/sample_ip_case.json'))
    assert any(c['ip_type'] == 'patent' for c in res.claim_charts)
