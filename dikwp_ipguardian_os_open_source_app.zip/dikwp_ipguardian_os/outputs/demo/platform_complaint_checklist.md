# Platform Complaint / Takedown Checklist

- Verify rights ownership and standing.
- Identify platform policy and legal basis.
- Attach preserved evidence and timestamps.
- Explain protectable elements, not just ideas or names.
- Use cautious language unless legal review confirms infringement.
- Include requested remedy: correction, attribution, removal, licensing contact, or halt of specific content.
- Preserve all correspondence.
