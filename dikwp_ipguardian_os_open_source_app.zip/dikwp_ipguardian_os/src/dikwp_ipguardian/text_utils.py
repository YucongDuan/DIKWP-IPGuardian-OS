import re, hashlib, math
from typing import Iterable, Set, List

CJK_RE = re.compile(r"[\u4e00-\u9fff]")
WORD_RE = re.compile(r"[A-Za-z0-9_\-]+|[\u4e00-\u9fff]{1}")

def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower()).strip()

def tokens(text: str) -> List[str]:
    return WORD_RE.findall(normalize(text))

def shingles(text: str, n: int = 3) -> Set[str]:
    t = tokens(text)
    if len(t) < n:
        return set(t)
    return {" ".join(t[i:i+n]) for i in range(len(t)-n+1)}

def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    A, B = set(a), set(b)
    if not A and not B:
        return 0.0
    return len(A & B) / max(1, len(A | B))

def similarity(a: str, b: str) -> float:
    tok = jaccard(tokens(a), tokens(b))
    tri = jaccard(shingles(a, 3), shingles(b, 3))
    bi = jaccard(shingles(a, 2), shingles(b, 2))
    return round(0.45*tok + 0.35*bi + 0.20*tri, 4)

def contains_any(text: str, phrases) -> bool:
    low = normalize(text)
    return any(normalize(p) in low for p in phrases)

def sha256_text(text: str) -> str:
    return hashlib.sha256((text or "").encode('utf-8')).hexdigest()

def clamp(x: float, lo=0.0, hi=1.0) -> float:
    return max(lo, min(hi, x))
