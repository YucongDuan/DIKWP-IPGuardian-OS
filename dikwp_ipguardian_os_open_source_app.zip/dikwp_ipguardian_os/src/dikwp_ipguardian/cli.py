import argparse, json
from pathlib import Path
from dataclasses import asdict
from .analyzer import load_case, analyze
from .reports import write_outputs
from .static_audit import run_static_audit


def main():
    parser = argparse.ArgumentParser(prog="ipguardian")
    sub = parser.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze")
    a.add_argument("case")
    a.add_argument("--out", default="outputs/demo")
    s = sub.add_parser("static-audit")
    s.add_argument("src")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args()
    if args.cmd == "analyze":
        case = load_case(args.case)
        res = analyze(case)
        write_outputs(res, args.out)
        print(json.dumps({"case_id": res.case_id, "decision": res.decision, "overall_score": res.overall_score}, ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        report = run_static_audit(args.src)
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
