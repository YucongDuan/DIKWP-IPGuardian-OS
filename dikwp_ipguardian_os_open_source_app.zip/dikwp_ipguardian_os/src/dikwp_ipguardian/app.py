try:
    import streamlit as st
except Exception:
    st = None

from .analyzer import load_case, analyze
from .reports import write_outputs

if st:
    st.title("DIKWP IPGuardian OS")
    st.write("Offline semantic-space IP infringement screening and enforcement preparation.")
    uploaded = st.file_uploader("Upload case JSON", type=["json"])
    if uploaded:
        import tempfile, json
        with tempfile.NamedTemporaryFile(delete=False, suffix='.json') as f:
            f.write(uploaded.read())
            path = f.name
        result = analyze(load_case(path))
        st.json({"decision": result.decision, "overall_score": result.overall_score})
        st.write("Signals")
        st.json([s.__dict__ for s in result.signals])
else:
    print("Install streamlit to use the app: pip install -e .[app]")
