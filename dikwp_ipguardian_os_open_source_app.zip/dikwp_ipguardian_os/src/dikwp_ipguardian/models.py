from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional

@dataclass
class EvidenceItem:
    id: str
    source_type: str
    title: str
    locator: str
    text: str
    timestamp: str = ""
    reliability: str = "provisional"
    custody_note: str = ""

@dataclass
class RightsAsset:
    id: str
    title: str
    ip_type: str
    owner: str
    registration_or_application: str = ""
    jurisdiction: str = "CN"
    status: str = "unknown"
    rights_chain: List[str] = field(default_factory=list)
    protected_elements: List[str] = field(default_factory=list)
    claim_elements: List[str] = field(default_factory=list)
    mark: str = ""
    goods_services: List[str] = field(default_factory=list)
    secrecy_measures: List[str] = field(default_factory=list)

@dataclass
class SuspectedUse:
    id: str
    actor: str
    channel: str
    url_or_location: str
    commercial_context: str
    target_text: str
    target_features: List[str] = field(default_factory=list)
    used_mark: str = ""
    goods_services: List[str] = field(default_factory=list)
    access_indicators: List[str] = field(default_factory=list)
    authorization_claim: str = "unknown"

@dataclass
class CaseInput:
    case_id: str
    title: str
    purpose: str
    assets: List[RightsAsset]
    suspected_uses: List[SuspectedUse]
    evidence: List[EvidenceItem]
    constraints: List[str] = field(default_factory=list)

@dataclass
class Signal:
    category: str
    score: float
    explanation: str
    evidence_refs: List[str] = field(default_factory=list)

@dataclass
class AnalysisResult:
    case_id: str
    decision: str
    overall_score: float
    signals: List[Signal]
    claim_charts: List[Dict[str, Any]]
    dikwp_ledger: List[Dict[str, Any]]
    evidence_ledger: List[Dict[str, Any]]
    enforcement_plan: List[Dict[str, Any]]
    residuals: List[str]
    action_boundary: List[str]


def to_dict(obj):
    return asdict(obj)
