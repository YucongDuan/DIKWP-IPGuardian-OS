import json, time
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Any, List, Tuple
from .models import RightsAsset, SuspectedUse, EvidenceItem, CaseInput, Signal, AnalysisResult
from .text_utils import similarity, tokens, jaccard, clamp, contains_any, sha256_text
from .dikwp import register_asset, register_use

STRONG_CLAIMS = ["guarantee", "100%", "完全相同", "必然侵权", "已经侵权", "唯一", "无争议"]


def load_case(path: str) -> CaseInput:
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    return CaseInput(
        case_id=data["case_id"],
        title=data.get("title", ""),
        purpose=data.get("purpose", ""),
        assets=[RightsAsset(**x) for x in data.get("assets", [])],
        suspected_uses=[SuspectedUse(**x) for x in data.get("suspected_uses", [])],
        evidence=[EvidenceItem(**x) for x in data.get("evidence", [])],
        constraints=data.get("constraints", [])
    )


def _best_feature_match(element: str, features: List[str], text: str) -> Tuple[float, str]:
    candidates = list(features) + [text]
    scored = [(similarity(element, c), c) for c in candidates if c]
    if not scored:
        return 0.0, ""
    return max(scored, key=lambda x: x[0])


def patent_chart(asset: RightsAsset, use: SuspectedUse) -> Dict[str, Any]:
    rows = []
    scores = []
    for idx, el in enumerate(asset.claim_elements):
        s, matched = _best_feature_match(el, use.target_features, use.target_text)
        scores.append(s)
        if s >= 0.72:
            status = "strong_semantic_match"
        elif s >= 0.48:
            status = "partial_or_needs_technical_evidence"
        else:
            status = "not_yet_supported"
        rows.append({
            "claim_element_index": idx + 1,
            "claim_element": el,
            "best_target_match": matched,
            "semantic_score": s,
            "status": status,
            "evidence_need": "backend logs, code, interface spec, customer delivery, source code, or technical demo" if status != "strong_semantic_match" else "confirm actual implementation and authorization"
        })
    coverage = sum(1 for s in scores if s >= 0.48) / max(1, len(scores))
    all_element_risk = min(scores) if scores else 0.0
    return {
        "asset_id": asset.id,
        "use_id": use.id,
        "ip_type": "patent",
        "coverage_ratio": round(coverage, 4),
        "all_elements_min_score": round(all_element_risk, 4),
        "rows": rows,
        "legal_boundary": "Patent infringement screening requires comparison against every claim element; semantic theme overlap is not enough."
    }


def copyright_signal(asset: RightsAsset, use: SuspectedUse) -> Signal:
    protected_text = "\n".join(asset.protected_elements)
    sim = similarity(protected_text, use.target_text)
    access_bonus = 0.12 if use.access_indicators else 0.0
    score = clamp(sim + access_bonus)
    return Signal(
        category="copyright_expression_similarity",
        score=round(score,4),
        explanation=f"Expression-level similarity proxy={sim}; access indicators={len(use.access_indicators)}. Ideas, methods and general concepts are not enough; protectable expression and substantial similarity need human review.",
        evidence_refs=[]
    )


def trademark_signal(asset: RightsAsset, use: SuspectedUse) -> Signal:
    mark_score = similarity(asset.mark or asset.title, use.used_mark or use.target_text[:80])
    goods_score = jaccard(asset.goods_services, use.goods_services)
    commercial_bonus = 0.15 if "commercial" in (use.commercial_context or "").lower() or "商业" in use.commercial_context else 0
    score = clamp(0.55*mark_score + 0.30*goods_score + commercial_bonus)
    return Signal(
        category="trademark_confusion_risk",
        score=round(score,4),
        explanation=f"Mark similarity={mark_score}; goods/services overlap={goods_score}; commercial context bonus={commercial_bonus}. Requires registered mark status, use-as-mark analysis and confusion review.",
        evidence_refs=[]
    )


def trade_secret_signal(asset: RightsAsset, use: SuspectedUse) -> Signal:
    secret_strength = 0.20 + min(0.35, 0.08 * len(asset.secrecy_measures))
    access_score = 0.25 if use.access_indicators else 0.0
    feature_score = max([similarity(x, use.target_text) for x in asset.protected_elements] or [0.0])
    score = clamp(secret_strength + access_score + 0.45*feature_score)
    return Signal(
        category="trade_secret_misappropriation_risk",
        score=round(score,4),
        explanation=f"Secrecy measures score={secret_strength}; access indicators={access_score}; semantic overlap={feature_score}. Requires proof of non-public value, reasonable secrecy measures, and improper acquisition/use.",
        evidence_refs=[]
    )


def generic_semantic_signal(asset: RightsAsset, use: SuspectedUse) -> Signal:
    source = "\n".join(asset.protected_elements + asset.claim_elements + [asset.title, asset.mark])
    target = use.target_text + "\n" + "\n".join(use.target_features) + "\n" + use.used_mark
    score = similarity(source, target)
    return Signal(
        category="dikwp_semantic_space_similarity",
        score=round(score,4),
        explanation="DIKWP semantic-space similarity across protected elements, claim features, target features, text and marks. This is a triage signal, not a legal conclusion.",
        evidence_refs=[]
    )


def analyze(case: CaseInput) -> AnalysisResult:
    signals: List[Signal] = []
    claim_charts: List[Dict[str, Any]] = []
    ledger: List[Dict[str, Any]] = []
    evidence_ledger: List[Dict[str, Any]] = []
    residuals = []

    for e in case.evidence:
        evidence_ledger.append({
            "id": e.id,
            "source_type": e.source_type,
            "title": e.title,
            "locator": e.locator,
            "timestamp": e.timestamp,
            "reliability": e.reliability,
            "hash": sha256_text(e.text),
            "supports": "source custody / public communication / comparison input",
            "does_not_support": "final infringement finding"
        })

    if not case.evidence:
        residuals.append("No evidence items were provided; all infringement signals are weak until evidence custody is established.")

    for asset in case.assets:
        ledger.append(register_asset(asdict(asset)))
        if not asset.rights_chain:
            residuals.append(f"Asset {asset.id} lacks a rights-chain record; enforcement should pause until ownership/authorization status is verified.")
        if asset.status.lower() not in ["active", "registered", "authorized", "published"]:
            residuals.append(f"Asset {asset.id} status is {asset.status}; verify official registry before enforcement.")
        for use in case.suspected_uses:
            ledger.append(register_use(asdict(use)))
            signals.append(generic_semantic_signal(asset, use))
            ip = asset.ip_type.lower()
            if ip == "patent":
                chart = patent_chart(asset, use)
                claim_charts.append(chart)
                signals.append(Signal(
                    category="patent_claim_element_coverage",
                    score=round(0.55*chart["coverage_ratio"] + 0.45*chart["all_elements_min_score"], 4),
                    explanation="Patent triage combines coverage ratio and weakest claim-element score. A patent claim normally needs all elements supported by actual implementation evidence.",
                    evidence_refs=[]
                ))
            elif ip == "copyright":
                signals.append(copyright_signal(asset, use))
            elif ip == "trademark":
                signals.append(trademark_signal(asset, use))
            elif ip == "trade_secret":
                signals.append(trade_secret_signal(asset, use))

    if any(contains_any(u.target_text, STRONG_CLAIMS) for u in case.suspected_uses):
        signals.append(Signal("unsupported_certainty_in_public_claims", 0.85, "Target or draft statements include unsupported certainty wording. Public enforcement communications should use suspected / risk / please clarify language until evidence closes.", []))

    if not claim_charts and any(a.ip_type.lower()=="patent" for a in case.assets):
        residuals.append("Patent assets exist but no claim chart could be generated; provide claim elements.")

    scores = sorted([s.score for s in signals], reverse=True)
    # Use top-risk aggregation for triage: a few high-risk signals should trigger preservation even when other IP theories are weak.
    overall = round(sum(scores[:min(5, len(scores))]) / max(1, min(5, len(scores))), 4)
    if overall >= 0.78:
        decision = "lawyer_review_and_evidence_preservation_urgent"
    elif overall >= 0.58:
        decision = "evidence_preservation_and_rights_chain_review"
    elif overall >= 0.35:
        decision = "monitor_and_collect_more_evidence"
    else:
        decision = "low_current_evidence_no_accusation"

    enforcement_plan = [
        {"step": 1, "name": "rights_chain_verification", "action": "Verify registration status, owner, license scope, assignment chain, patent annual fee or copyright/trademark registry status.", "boundary": "No public accusation before rights chain is verified."},
        {"step": 2, "name": "evidence_preservation", "action": "Preserve original pages, screenshots, timestamps, source URLs, public ads, product demos, customer materials, code artifacts if lawfully accessible.", "boundary": "Do not hack, deceive, scrape in violation of law, or access non-public systems."},
        {"step": 3, "name": "semantic_space_comparison", "action": "Compare protected elements, claim elements, marks, trade-secret features and target behavior in DIKWP semantic space.", "boundary": "Similarity is only a triage signal; legal elements must be satisfied."},
        {"step": 4, "name": "authorization_check", "action": "Ask whether target has license, cooperation, assignment, fair use, independent creation, exhaustion, prior right, public domain or other defense.", "boundary": "Record defenses instead of suppressing them."},
        {"step": 5, "name": "human_legal_review", "action": "Send report, claim charts and evidence ledger to IP counsel or qualified IP professional.", "boundary": "Tool output is not legal advice."},
        {"step": 6, "name": "graduated_response", "action": "Choose non-public fact-check letter, platform complaint, negotiation, administrative complaint, preservation application or lawsuit based on evidence strength and counsel advice.", "boundary": "Avoid bad-faith takedowns and overbroad threats."}
    ]

    action_boundary = [
        "Do not publish 'already infringed' unless counsel verifies legal elements and evidence.",
        "Use 'suspected', 'risk', 'please clarify source/authorization' language before evidence closes.",
        "Do not use this system to harass competitors, suppress fair use, or threaten lawful commentary/research.",
        "Do not access private systems, steal credentials, bypass access controls, or collect personal data unlawfully.",
        "Human legal review is required before takedown, lawyer letter, administrative complaint or lawsuit."
    ]

    return AnalysisResult(case.case_id, decision, overall, signals, claim_charts, ledger, evidence_ledger, enforcement_plan, residuals, action_boundary)
