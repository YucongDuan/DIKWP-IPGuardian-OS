import json, csv
from dataclasses import asdict
from pathlib import Path
from typing import Any


def write_outputs(result, out_dir: str):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = asdict(result)
    (out/"ipguardian_report.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"evidence_ledger.json").write_text(json.dumps(result.evidence_ledger, ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"dikwp_ip_ledger.json").write_text(json.dumps(result.dikwp_ledger, ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"claim_charts.json").write_text(json.dumps(result.claim_charts, ensure_ascii=False, indent=2), encoding="utf-8")
    with (out/"semantic_infringement_matrix.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["category","score","explanation"])
        w.writeheader()
        for s in result.signals:
            w.writerow({"category": s.category, "score": s.score, "explanation": s.explanation})
    md = []
    md.append("# DIKWP IPGuardian Enforcement Preparation Plan\n")
    md.append(f"Decision: **{result.decision}**\n")
    md.append(f"Overall score: **{result.overall_score}**\n")
    md.append("\n## Graduated response\n")
    for step in result.enforcement_plan:
        md.append(f"### {step['step']}. {step['name']}\n")
        md.append(f"Action: {step['action']}\n\nBoundary: {step['boundary']}\n")
    md.append("\n## Residuals\n")
    for r in result.residuals:
        md.append(f"- {r}\n")
    md.append("\n## Action boundary\n")
    for b in result.action_boundary:
        md.append(f"- {b}\n")
    (out/"enforcement_plan.md").write_text("\n".join(md), encoding="utf-8")
    letter = f"""# Fact-Check / Rights Clarification Letter Draft\n\nThis draft is not legal advice and must be reviewed by counsel.\n\nSubject: Request for clarification regarding possible use of protected DIKWP-related intellectual property\n\nDear recipient,\n\nPublic materials appear to describe technologies, marks, expressions or features that may overlap with protected rights held or controlled by the rights holder. At this stage we do not assert a final infringement conclusion. We request clarification regarding:\n\n1. the technical source and implementation boundary;\n2. any authorization, license, assignment, cooperation or independent-development evidence;\n3. the scope of any use of DIKWP-related terminology, methods, marks, code, datasets, documents or patents;\n4. whether public materials should be corrected to avoid confusion or misattribution.\n\nPlease preserve relevant evidence, including product materials, technical documentation, logs, code records, marketing materials and authorization documents.\n\nSincerely,\n[Rights Holder / Counsel]\n"""
    (out/"fact_check_letter_draft.md").write_text(letter, encoding="utf-8")
    takedown = """# Platform Complaint / Takedown Checklist\n\n- Verify rights ownership and standing.\n- Identify platform policy and legal basis.\n- Attach preserved evidence and timestamps.\n- Explain protectable elements, not just ideas or names.\n- Use cautious language unless legal review confirms infringement.\n- Include requested remedy: correction, attribution, removal, licensing contact, or halt of specific content.\n- Preserve all correspondence.\n"""
    (out/"platform_complaint_checklist.md").write_text(takedown, encoding="utf-8")
