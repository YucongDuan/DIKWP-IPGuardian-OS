from typing import Dict, Any, List
from .text_utils import sha256_text


def register_asset(asset: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "object_id": asset.get("id"),
        "object_type": "rights_asset",
        "D": {
            "title": asset.get("title"),
            "ip_type": asset.get("ip_type"),
            "registration_or_application": asset.get("registration_or_application"),
            "protected_elements": asset.get("protected_elements", []),
            "claim_elements": asset.get("claim_elements", [])
        },
        "I": {
            "jurisdiction": asset.get("jurisdiction", "CN"),
            "status": asset.get("status"),
            "rights_chain_count": len(asset.get("rights_chain", []))
        },
        "K": {
            "legal_theory": "ip-type-specific: patent claim coverage / copyright expression similarity / trademark confusion / trade secret misappropriation",
            "semantic_space_role": "source object for comparison"
        },
        "W": {
            "boundary": "screening only; no final legal conclusion",
            "fair_use_or_legitimate_use_guard": True,
            "bad_faith_takedown_guard": True
        },
        "P": {
            "purpose": "protect legitimate IP while avoiding false accusation and overclaiming",
            "success": "produce evidence-ledger and lawyer-ready review pack"
        },
        "R": {
            "reliability": "borrowed/provisional until official registry, rights chain, and legal review are verified",
            "hash": sha256_text(str(asset))
        }
    }


def register_use(use: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "object_id": use.get("id"),
        "object_type": "suspected_use",
        "D": {
            "actor": use.get("actor"),
            "channel": use.get("channel"),
            "url_or_location": use.get("url_or_location"),
            "target_text_excerpt": (use.get("target_text") or "")[:500]
        },
        "I": {
            "commercial_context": use.get("commercial_context"),
            "authorization_claim": use.get("authorization_claim")
        },
        "K": {
            "comparison_need": "map target features to protected elements and legal theory"
        },
        "W": {
            "risk": "semantic similarity can be lawful; requires rights-chain, authorization and legal element review"
        },
        "P": {
            "purpose": "identify evidence gaps and enforcement options without premature accusation"
        },
        "R": {
            "hash": sha256_text(str(use)),
            "reliability": "depends on source custody"
        }
    }
