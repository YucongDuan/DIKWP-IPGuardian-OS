import ast
from pathlib import Path

FORBIDDEN_IMPORTS = {"subprocess", "socket", "requests", "urllib", "http.client", "ftplib", "paramiko", "telnetlib"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__", "open"}

class Visitor(ast.NodeVisitor):
    def __init__(self, filename):
        self.filename = filename
        self.findings = []
    def visit_Import(self, node):
        for alias in node.names:
            if alias.name.split('.')[0] in FORBIDDEN_IMPORTS:
                self.findings.append({"file": self.filename, "type": "forbidden_import", "name": alias.name})
        self.generic_visit(node)
    def visit_ImportFrom(self, node):
        mod = (node.module or '').split('.')[0]
        if mod in FORBIDDEN_IMPORTS:
            self.findings.append({"file": self.filename, "type": "forbidden_import", "name": node.module})
        self.generic_visit(node)
    def visit_Call(self, node):
        name = ""
        if isinstance(node.func, ast.Name):
            name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            name = ''  # attribute calls such as re.compile are allowed; direct dynamic builtins are not
        if name in {"eval", "exec", "compile", "__import__"}:
            self.findings.append({"file": self.filename, "type": "forbidden_call", "name": name})
        self.generic_visit(node)

def run_static_audit(src_dir: str):
    findings = []
    for p in Path(src_dir).rglob('*.py'):
        try:
            tree = ast.parse(p.read_text(encoding='utf-8'))
            v = Visitor(str(p))
            v.visit(tree)
            findings.extend(v.findings)
        except Exception as e:
            findings.append({"file": str(p), "type": "parse_error", "error": str(e)})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, or private-system access helpers in the offline core."
    }
