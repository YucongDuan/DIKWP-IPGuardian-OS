# Contributing

Contributions should improve evidence quality, legal boundary clarity, semantic comparison robustness, attribution integrity, and human-review workflows.

Do not contribute code for covert scraping, credential collection, unauthorized access, automated legal threats, or mass harassment.
